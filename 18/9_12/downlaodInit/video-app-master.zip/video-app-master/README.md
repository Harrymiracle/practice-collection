# AngularJS Foundation - Video Application

A sleek AngularJS Application to browse youtube videos

## Branches

Each branch represents the module with the AngularJS Foundation application exercises.

## Installation

1. `npm install -g grunt-cli`
2. `npm install -g grunt`
3. `npm install`
4. `grunt install`
