平安银行社区微信端angularjs版
============
2014-12-31
修复定位bug刷新位置的问题

2014-12-23 
三块内容：
 营业网点，商户，金融超市

启动问题
============
很多朋友一直在问如何启动，最简单本地找到文件夹根目录启http-server，或者装web server for chrome整个包丢进去启动

更新问题
============
这个只是一小部分粗糙功能，是一个展示培训栗子，也不在更新，不能用于正式环境，bug肯定很多：）

您的鼓励是我持续开源的动力：）
============
<img src="https://github.com/monw3c/angularjs_pingan/blob/master/images/3.pic.jpg" width="300">
