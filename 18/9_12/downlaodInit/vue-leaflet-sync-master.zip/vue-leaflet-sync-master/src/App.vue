<template>
  <router-view></router-view>
</template>

<script>
</script>


<style>
body, html {
    margin: 0;
    height:100%;
}
</style>
