<style>

.header {
    background-image: url('../assets/header.png');
    background-color: #1b3fa8;
    height: 120px;
}

</style>

<template>
<div class="header"></div>
</template>

<script>
</script>
