<template>
    <header class="main-header">
        <h1>Todo</h1>
    </header>
</template>

<style lang="stylus" scoped>
    .main-header {
        text-align center
        h1 {
            font-size 100px
            color rgba(175, 47, 47, 0.4)
            font-weight 100
            margin 20px
        }
    }
</style>
