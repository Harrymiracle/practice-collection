const autoprefixer = require('autoprefixer')

module.exports = {
    plugins: [
        autoprefixer() // 优化 css，游览器前缀
    ]
}
