# shoppingCart
慕课网 - 使用vue2.0实现购物车和地址选配功能

* 学会如何创建一个vue实例
* 指令 v-model v-show v-text v-bind v-on v-if v-for
* 过滤器的使用, computed的使用

------------------------------------
局部过滤器的使用
![photo](https://github.com/LewanYang/shoppingCart/blob/master/Screenshots/filter/filter1.jpg)
![photo](https://github.com/LewanYang/shoppingCart/blob/master/Screenshots/filter/filter2.jpg)

--------------------------------------
全局过滤器的使用
![photo](https://github.com/LewanYang/shoppingCart/blob/master/Screenshots/filter/filter3.jpg)
![photo](https://github.com/LewanYang/shoppingCart/blob/master/Screenshots/filter/filter4.jpg)

--------------------------------------
一种简单的选择固定选项卡的方法：
![photo](https://github.com/LewanYang/shoppingCart/blob/master/Screenshots/selectCard.jpg)
![photo](https://github.com/LewanYang/shoppingCart/blob/master/Screenshots/selectCard2.jpg)
