import Vue from 'vue';
import Toast from '../src/index';

describe('my test', function () {
    expect(true).to.be.true;
});