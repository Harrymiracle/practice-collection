export  const SELECT_DATE = "SELECT_DATE";

export const selectDate = (date)=>(
    {
        type:SELECT_DATE,
        date:date
    }
)
