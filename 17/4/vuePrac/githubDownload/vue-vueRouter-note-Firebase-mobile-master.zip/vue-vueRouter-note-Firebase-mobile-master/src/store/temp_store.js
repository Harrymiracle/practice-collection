//全局变量，便于路由和路由之间传递数据
export const tmp = {
	note: {
		id: '',
		title: '',
		content: '',
		category: ''
	}
}