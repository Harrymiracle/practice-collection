/*路由配置*/
export default function(router) {
	
}