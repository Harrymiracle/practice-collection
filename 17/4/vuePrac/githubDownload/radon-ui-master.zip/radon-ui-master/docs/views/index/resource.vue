<template>
<div class="ex-content">
    <div class="ex-card">
    <mark>
        <textarea class="ex-mark-text">
# 资源

### Vuejs

RadonUI 基于 Vuejs 开发，[Vue.js 中文文档](http://vuejs.org.cn/)

### 图标 Icon

RadonUI 使用 ionic 的 icon 集合 [<i class="ion-ionic"></i>  ionicons](http://ionicons.com/)



        </textarea>
    </mark>
    </div>
</div>
</template>
<script>
import { Mark } from '../index'

export default {
    components: {
        Mark
    }
}
</script>