## Radon UI docs

### 目录介绍

#### 文件

- main.js       docs 项目入口文件
- App.vue       Vue 根组件

#### 目录

- views         组件文档与演示页
- router        路由配置
- lib           docs 公用库文件
- components    docs 共用组件文件
- assets        docs 静态文件
