import Breadcrumb from './Breadcrumb.vue'
import BreadcrumbItem from './BreadcrumbItem.vue'

export default {
  Breadcrumb,
  BreadcrumbItem
}