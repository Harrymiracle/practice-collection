import Loader from './Loader.vue'

export default {
  Loader
}