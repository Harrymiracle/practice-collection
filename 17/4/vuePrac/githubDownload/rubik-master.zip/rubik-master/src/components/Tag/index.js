import Tag from './Tag.vue'

export default {
  Tag
}