import Pagination from './Pagination.vue'

export default {
  Pagination
}