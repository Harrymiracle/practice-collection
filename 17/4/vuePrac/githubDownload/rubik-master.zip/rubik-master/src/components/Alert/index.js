import Alert from './Alert.vue'

export default {
  Alert
}