import Btn from './Button.vue'

export default {
  Btn
}