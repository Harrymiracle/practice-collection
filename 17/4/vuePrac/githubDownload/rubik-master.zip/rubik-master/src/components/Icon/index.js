import Icon from './Icon.vue'

export default {
    Icon
}