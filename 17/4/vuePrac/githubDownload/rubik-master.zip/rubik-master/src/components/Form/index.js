import Checkbox from './Checkbox.vue'
import Radio from './Radio.vue'
import Select from './Select.vue'
import Input from './Input.vue'
import File from './File.vue'

export default {
  Checkbox,
  Radio,
  Select,
  Input,
  File
}