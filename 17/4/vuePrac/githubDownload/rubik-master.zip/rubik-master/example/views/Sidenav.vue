<template>
  <article>
    <h1>SideNav</h1>

    <h2>coming soon</h2>
    
    
  </article>
</template>

<script>
export default {
  name: '',
  data(){
    return {
      
    }
  }
}
</script>

<style scoped lang="stylus">

</style>
