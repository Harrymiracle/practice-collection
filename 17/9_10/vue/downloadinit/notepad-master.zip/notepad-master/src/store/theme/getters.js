/**
 * Created by linxin on 2017/3/11.
 */
export default {
    getTheme(states){
        return states.theme;
    },
};