/**
 * Created by linxin on 2017/3/11.
 */
export default {
    switch_theme : ({commit}, param) => commit('SWITCHTHEME',{theme: param})
}