/**
 * Created by linxin on 2017/3/10.
 */
// 添加事件
export const ADDEVENT = 'ADDEVENT';

// 移至已完成
export const EVENTDONE = 'EVENTDONE';

// 移至未完成
export const EVENTTODO = 'EVENTTODO';

// 移至已取消
export const EVENTCANCEL = 'EVENTCANCEL';

// 清除所有事件
export const CLEAREVENT = 'CLEAREVENT';

// 删除单个事件
export const DELEVENT = 'DELEVENT';

// 编辑事件
export const EDITEVENT = 'EDITEVENT';

// 导入数据
export const UPLOADEVENT = 'UPLOADEVENT';
