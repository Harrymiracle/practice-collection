<template>
    <footer class="footer">
        © 2017 <a href="https://github.com/lin-xin" target="_blank">linshuai</a> 强力驱动
    </footer>
</template>

<style>
    .footer{
        position: fixed;
        bottom: 0;
        width: 100%;
        height: 50px;
        line-height: 50px;
        background: #f8f8f8;
        text-align: center;
        font-size: 14px;
        color: #666;
        border-top: 1px solid #ddd;
    }
    .footer a{
        color: #666;
    }
</style>