# vue2-firebase-REST-note-mobile
mobile note base vue2 and firebse REST



1. install:

> npm i

2. dev:

> npm run dev

3. build: 

> npm run build