export default {
  props: ['data']
}
