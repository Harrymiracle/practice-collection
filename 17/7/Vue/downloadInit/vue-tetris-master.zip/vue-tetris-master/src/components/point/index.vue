<template>
  <div>
    <p>{{label}}</p>
    <Number :number="number"/>
  </div>
</template>
<script src="./index.js">
</script>

