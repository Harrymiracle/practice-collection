<template>
  <div class="bg music" :class="data?'':'c'">
  </div>
</template>

<script src="./index.js">
</script>


<style lang="less">
@import './index.less';
</style>