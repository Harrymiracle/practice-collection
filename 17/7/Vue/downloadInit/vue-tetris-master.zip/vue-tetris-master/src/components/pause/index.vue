<template>
  <div class="bg pause" :class="{'c':showPause}" />
</template>

<script src="./index.js">
</script>


<style lang="less">
@import './index.less';
</style>
