# Vue.js + Node Time Tracker

This repo goes along with the Vue.js + Node time tracker tutorial available at [Scotch.io](https://scotch.io).

![](https://cdn.scotch.io/9/ILKc5RKTTvuv2JbkDbSj_vue-time-5.png)

## Install and Run

```bash
npm install
npm run dev
```

**Note:** The server code isn't ready yet :)

The app will be served at `localhost:8080`.

## License

MIT
