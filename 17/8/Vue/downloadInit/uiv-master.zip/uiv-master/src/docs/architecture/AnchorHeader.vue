<template>
  <div>
    <h2 class="page-header">
      <span>{{text}}</span>
    </h2>
  </div>
</template>

<script>
  export default {
    props: ['text', 'sourceFolder']
  }
</script>

<style lang="less" rel="stylesheet/less" scoped>

</style>
