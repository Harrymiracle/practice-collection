import Vue from 'vue'
const bus = new Vue()
const events = {
  TOGGLE_ASIDE: 'TOGGLE_ASIDE'
}

export {bus, events}
