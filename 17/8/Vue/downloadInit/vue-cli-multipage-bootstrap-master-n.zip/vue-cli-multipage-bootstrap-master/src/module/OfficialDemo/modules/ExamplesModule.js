/**
 * Created by zhoou on 2016/11/30.
 */
const ExamplesModule = {
  state: {
    title: 'vue 小项目集锦',
    Lists: [
      {pname: 'TableHome', text: '实现table的各种复杂功能', url: '/tablehome.html'},
      {pname: 'PopupsHome', text: '实现各种弹窗功能', url: '/popupshome.html'},
      {pname: 'CarouselHome', text: '各类实现轮播效果', url: '/carouselhome.html'},
      {pname: 'FormLogin', text: '实现表单登陆功能', url: '/formlogin.html'},
      {pname: '......', text: '敬请期待 please stay tuned !', url: ''}
    ]
  },
  getters: {},
  mutations: {},
  actions: {}
}

export default ExamplesModule
