/**
 * Created by zhoou on 2016/12/5.
 */
const AdvanceModule = {
  state: {
    title: '',
    Lists: [
      {pname: 'TableHome', text: '实现table的各种复杂功能', url: '/tablehome.html'},
      {pname: '......', text: '敬请期待 please stay tuned !', url: ''}
    ]
  },
  getters: {},
  mutations: {},
  actions: {}
}

export default AdvanceModule
