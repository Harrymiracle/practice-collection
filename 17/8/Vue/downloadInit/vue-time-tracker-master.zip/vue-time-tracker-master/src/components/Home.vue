<template>
  <div class="jumbotron">
    <h1>Vue Time Tracker</h1>
    <p>
      <strong>
        Get started by <a v-bind:href="'/time-entries'">creating a time entry</a>.
      </strong>
    </p>  
  </div>
</template>

<script>
	export default {

	};
</script>

<style type="text/css">
	
</style>