"use strict";

module.exports = function () {
  return this.data;
};