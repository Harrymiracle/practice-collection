"use strict";

module.exports = function () {
      return Object.keys(this.opts.templates);
};