"use strict";

module.exports = function () {
  return JSON.stringify(this.customQueries);
};