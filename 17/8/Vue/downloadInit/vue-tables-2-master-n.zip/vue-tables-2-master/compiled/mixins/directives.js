'use strict';

module.exports = {
    input: require('../directives/input'),
    select: require('../directives/select')
};