"use strict";

module.exports = function (data) {

    this.count = data.length;

    return data;
};