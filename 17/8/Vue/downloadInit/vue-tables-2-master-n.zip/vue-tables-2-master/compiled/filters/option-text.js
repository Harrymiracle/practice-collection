'use strict';

module.exports = function (value, column) {

  var list = this.listColumnsObject[column];

  if (typeof list[value] == 'undefined') return value;

  return list[value];
};