"use strict";

module.exports = function () {
  this.serverSearch();
};