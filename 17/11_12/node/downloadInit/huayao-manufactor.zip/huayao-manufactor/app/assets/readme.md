#华药物流移动端-药企（厂家）静态页面文件目录
##commoncss 		公用的css
##commonjs 			公用的js
##fonts 			字体库
##view 				前端页面
    index.html            首页
    ###login            登录模块
        login.html            登录页
        register.html         注册页面

    ###personcenter           个人中心
        personcenter.html     个人中心
        mailList.html         企业（个人）通讯录
        bindingPhone.html     绑定手机号码
		myIntegral.html       我的积分
        addContact.html       添加联系人
        address.html          我的地址
        changePhoneNum.html   修改手机号
        complaintInfo.html    投诉信息
        myComplaint.html      我的投诉
        personInfo.html       个人信息
        searchContacts.html   搜索联系人

    ###task             任务
        task.html             任务
        address.html          取送货地址
        selectordertype.html  选择订单类型
        tasksubmit.html       任务提交
        tasksubmitsearch.html 药品搜索
        taskdetail.html       任务详情页
        drugdetails.html      药品详情
        livedetails.html      实时位置
        drugconfirm.html      药品提交

    ###
